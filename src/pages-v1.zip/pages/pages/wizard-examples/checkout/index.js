// ** Demo Components Imports
import Checkout from 'src/views/pages/wizard-examples/checkout'

const WizardExamples = () => {
  return <Checkout />
}

export default WizardExamples
